//
//  Bot.swift
//  Craphead
//
//  Created by Janis Kreicmanis on 11/05/2020.
//  Copyright © 2020 Janis Kreicmanis. All rights reserved.
//

import Foundation
import SpriteKit

extension GameScene {
    
    func computerMakeMove()
    {
        //sort cards
        computerCardsInHand.cards.sort(by: {
            ( $1.dmg() == 2 || $1.dmg() == 3 || $1.dmg() == 7 || $1.dmg() == 10) || $0.dmg() < $1.dmg()
        })
        
        for (idx, c) in computerCardsInHand.cards.enumerated() {
            print("\(idx). \(c.name())  dmg:\(c.dmg())")
        }
        
        //Test for all cards
        var currentCardDmg = -1
        for card in computerCardsInHand.cards {
            if(canMakeThisMove(player_card: card) && (currentCardDmg == -1)){
                moveCardToCenterBot(c: card)
                currentCardDmg = card.dmg()
            }else if(currentCardDmg == card.dmg()){
                moveCardToCenterBot(c: card)
            }
        }
        
        
        if(currentCardDmg == -1){
            while !stackDeck.empty() {
                let cpuCard = stackDeck.getCard()
                computerCardsInHand.addCard(card: cpuCard)
                let dst = CGPoint(x: self.frame.size.width/2, y: (self.frame.size.height*0.8))
                let path = createCurvedPath(from: cpuCard.position, to: dst, varyingBy: 500)
                let squareSpeed = CGFloat(arc4random_uniform(2000)) + 1200
                let moveAction = SKAction.follow(path, asOffset: false, orientToPath: false, speed: CGFloat(squareSpeed))
                cpuCard.run(SKAction.group([moveAction]), completion: {self.sortComputerCards()})
            }
            return
        }
        
        
        
        if (currentCardDmg == 3){
            // tris uz dead
            //parejas playerim
            
            //            while !stackDeck.empty() {
            //
            //             let playerCard = mainDeck.getCard()
            //
            //
            //             playerCardsInHand.addCard(card: playerCard)
            //             let dst = CGPoint(x: self.frame.size.width/2, y: (self.frame.size.height*0.2))
            //             let path = createCurvedPath(from: playerCard.position, to: dst, varyingBy: 500)
            //             let squareSpeed = CGFloat(arc4random_uniform(2000)) + 1200
            //             let moveAction = SKAction.follow(path, asOffset: false, orientToPath: false, speed: CGFloat(squareSpeed))
            //             playerCard.run(SKAction.group([moveAction]), completion: {self.sortPlayerCards()})
            //            }
            //
            
        }else if (currentCardDmg == 10){
            print("NONONONN 10")
            
            while !stackDeck.empty() {
                moveToDeadZone(card: stackDeck.getCard())
            }
            //pickUpCPUcards()
            //computerMakeMove()
            return
        }
        
        //        if(isStackDead()){
        //            while !stackDeck.empty() {
        //                moveToDeadZone(card: stackDeck.getCard())
        //            }
        //            pickUpCPUcards()
        //            computerMakeMove()
        //            return
        //        }
        
        ///  pickUpCPUcards()
        
        
        
    }
    
    func findSameDmgCard(dmg: Int){
        for card in computerCardsInHand.cards {
          if(dmg == card.dmg()){
                moveCardToCenterBot(c: card)
            }
        }
        
        
        
    }
    
    func moveCardToCenterBot(c: Card){
        var card = c
        card = changeStack(dest_deck: stackDeck, from_deck: computerCardsInHand, card: card)
        let dest = CGPoint(x: self.frame.size.width/2,y: self.frame.size.height/2)
        let path = createCurvedPath(from: card.position, to: dest, varyingBy: 500)
        let squareSpeed = 500
        let moveAction = SKAction.follow(path, asOffset: false, orientToPath: false, speed: CGFloat(squareSpeed))
        card.movable = false
        card.run(SKAction.group([moveAction]),completion: {self.findSameDmgCard(dmg: card.dmg())})
    }
}
